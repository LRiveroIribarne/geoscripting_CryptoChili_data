The following documents are a subset of the surveyed area near Camp 41 in Indonesia.
We have provided three main files that will provide enough information on the area.

Canopy Height Model (CHM.tif)
The CHM describes the height of the trees in the plot.
The units are in meters, thus the ground floor of the forest is set to 0 meters.
The highest tree in the plot is around 60+ meters.

Multispectral Image (Multispectral.tif)
This image is comprised of 5 bands: Blue, Green, Red, Red-Edge, NIR.
The values on each band have not been normalized.
A linear normalization could help bring the values to a range between 0 and 255.

Thermal Image (Thermal.tif)
The thermal image consists of four bands. 
Band 4 is a generated output from the processing software that includes no useful information.
Bands 1 to 3 display the heat eminating from the source
So red = hot green = cold
